<?php
/*
    Template Name: Single Page Theme Page
    http://qnimate.com/creating-a-one-page-wordpress-theme/
*/

